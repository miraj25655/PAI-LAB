from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

books = {
    "python": "Python Programming by John Zelle is available",
    "ai": "Artificial Intelligence by Stuart Russell is available",
    "dbms": "Database System Concepts is currently issued"
}

info = {
    "hours": "The library is open from 9 AM to 6 PM, Monday to Friday",
    "due": "Books should be returned within 14 days"
}

def reply(text):
    text = text.lower()

    for key in books:
        if key in text:
            return books[key]

    if "hour" in text or "open" in text:
        return info["hours"]

    if "due" in text or "return" in text:
        return info["due"]

    return "I didn’t quite get that. You can ask about books, timings, or returns."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def get_bot_reply():
    message = request.form.get("message", "")
    return jsonify({"response": reply(message)})

if __name__ == "__main__":
    app.run(debug=True)
